<?php

session_start();

function intro() {
    echo "<h2>Welcome to the Adventure Game!</h2>";
    echo "<p>You find yourself at the entrance of a dark cave.</p>";
    echo '<form method="post"><input type="submit" name="action" value="Enter Cave"></form>';
    echo '<form method="post"><input type="submit" name="action" value="Stay Outside"></form>';
}

function enterCave() {
    echo "<h2>You step into the cave and it's pitch black.</h2>";
    echo '<form method="post"><input type="submit" name="action" value="Light Torch"></form>';
    echo '<form method="post"><input type="submit" name="action" value="Stay in the Dark"></form>';
}

function lightTorch() {
    echo "<h2>With the torch lit, you can see the cave walls are lined with ancient carvings.</h2>";
    echo '<form method="post"><input type="submit" name="action" value="Explore Further"></form>';
    echo '<form method="post"><input type="submit" name="action" value="Leave"></form>';
}

// Handle form submissions
$action = $_POST['action'] ?? null;

switch ($action) {
    case "Start Game":
        intro();
        break;
    case "Enter Cave":
        enterCave();
        break;
    case "Stay Outside":
        echo "<p>You decided to stay outside. The adventure ends here.</p>";
        break;
    case "Light Torch":
        lightTorch();
        break;
    case "Stay in the Dark":
        echo "<p>You stumble in the dark and fall into a pit. Game over.</p>";
        break;
    case "Explore Further":
        echo "<p>You discover a hidden treasure chest filled with gold!</p>";
        break;
    case "Leave":
        echo "<p>You leave the cave, missing out on potential treasures.</p>";
        break;
    default:
        intro();
        break;
}

?>
